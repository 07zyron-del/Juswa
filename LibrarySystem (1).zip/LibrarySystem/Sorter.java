import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Merge sort written by hand.
 * Time: O(n log n) in best, average and worst case. Space: O(n) for the merged lists.
 * Stable: equal elements keep their original order.
 */
public class Sorter {
    public static <T> List<T> mergeSort(List<T> list, Comparator<? super T> cmp) {
        if (list.size() <= 1) return new ArrayList<>(list);
        int mid = list.size() / 2;
        List<T> left = mergeSort(list.subList(0, mid), cmp);
        List<T> right = mergeSort(list.subList(mid, list.size()), cmp);
        return merge(left, right, cmp);
    }

    private static <T> List<T> merge(List<T> a, List<T> b, Comparator<? super T> cmp) {
        List<T> out = new ArrayList<>(a.size() + b.size());
        int i = 0, j = 0;
        while (i < a.size() && j < b.size()) {
            if (cmp.compare(a.get(i), b.get(j)) <= 0) out.add(a.get(i++));
            else out.add(b.get(j++));
        }
        while (i < a.size()) out.add(a.get(i++));
        while (j < b.size()) out.add(b.get(j++));
        return out;
    }
}
