import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Web front end for the library. Java is the back end (JDK built-in HttpServer, no libraries);
 * index.html is the front end and talks to the JSON endpoints below with fetch().
 * All logic stays in Library, so this class only translates HTTP <-> Library calls.
 *
 *   GET  /api/state?view=default|bst|id|type|days&q=...
 *   POST /api/borrow | /api/return | /api/reserve   (memberId, itemId)
 *   POST /api/undo
 *   POST /api/item (type, id, title, extra)   POST /api/member (id, name)
 */
public class LibraryServer {
    private static final Library lib = new Library();

    public static void main(String[] args) throws IOException {
        seed();
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 8080;
        HttpServer server = HttpServer.create(new InetSocketAddress("localhost", port), 0);
        server.createContext("/", LibraryServer::page);
        server.createContext("/api/", LibraryServer::api);
        server.start();
        System.out.println("Library server running. Open http://localhost:" + port + " in your browser.");
        System.out.println("Press Ctrl+C to stop.");
    }

    // ---------- static page ----------
    private static void page(HttpExchange ex) throws IOException {
        String path = ex.getRequestURI().getPath();
        if (!path.equals("/") && !path.equals("/index.html")) { send(ex, 404, "text/plain", "Not found"); return; }
        send(ex, 200, "text/html; charset=utf-8", loadHtml());
    }

    /** Uses index.html next to the program if present (easy to edit), otherwise the copy built into WebPage. */
    private static String loadHtml() throws IOException {
        for (String p : new String[]{"index.html", "LibrarySystem/index.html", "src/index.html"}) {
            if (Files.exists(Path.of(p))) return Files.readString(Path.of(p));
        }
        return WebPage.HTML;
    }

    // ---------- JSON API ----------
    private static void api(HttpExchange ex) throws IOException {
        Map<String, String> p = parse(ex.getRequestURI().getRawQuery());
        if ("POST".equals(ex.getRequestMethod()))
            p.putAll(parse(new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8)));
        String json;
        try {
            synchronized (lib) { json = handle(ex.getRequestURI().getPath(), p); }
        } catch (IllegalArgumentException | IllegalStateException e) {
            json = result(false, e.getMessage());
        }
        send(ex, 200, "application/json; charset=utf-8", json);
    }

    private static String handle(String path, Map<String, String> p) {
        switch (path) {
            case "/api/state":   return state(p);
            case "/api/borrow":  return result(true, lib.borrow(get(p, "memberId"), get(p, "itemId")));
            case "/api/return":  return result(true, lib.returnItem(get(p, "memberId"), get(p, "itemId")));
            case "/api/reserve": return result(true, lib.reserve(get(p, "memberId"), get(p, "itemId")));
            case "/api/undo":    return result(true, lib.undo());
            case "/api/member": {
                Member m = new Member(get(p, "id"), get(p, "name"));
                lib.addMember(m);
                return result(true, "Welcome, " + m.getName() + "!");
            }
            case "/api/item": {
                String id = get(p, "id"), title = get(p, "title"), extra = get(p, "extra");
                LibraryItem item;
                switch (get(p, "type")) {
                    case "Book": item = new Book(id, title, extra); break;
                    case "Magazine": item = new Magazine(id, title, extra); break;
                    case "DVD":
                        try { item = new DVD(id, title, Integer.parseInt(extra.trim())); }
                        catch (NumberFormatException e) { throw new IllegalArgumentException("Duration must be a number."); }
                        break;
                    default: throw new IllegalArgumentException("Unknown item type.");
                }
                lib.addItem(item);
                return result(true, "Added " + item.getType() + " “" + item.getTitle() + "”.");
            }
            default: throw new IllegalStateException("Unknown endpoint.");
        }
    }

    private static String state(Map<String, String> p) {
        List<LibraryItem> list;
        String how;
        String q = get(p, "q").trim();
        if (!q.isEmpty()) {
            LibraryItem hit;
            try { hit = lib.getItem(q); }                           // HashMap lookup by ID
            catch (IllegalStateException e) { hit = lib.searchByTitle(q); } // BST lookup by title
            list = hit == null ? List.of() : List.of(hit);
            how = "Search: ID lookup uses the HashMap, O(1). Title lookup uses the BST, O(log n) on average.";
        } else {
            switch (get(p, "view")) {
                case "bst":
                    list = lib.browseAlphabetical();
                    how = "BST in-order traversal (left, node, right) gives A–Z in O(n).";
                    break;
                case "id":
                    list = lib.listSorted(Comparator.comparing(LibraryItem::getId));
                    how = "Hand-written merge sort: O(n log n) time, O(n) space.";
                    break;
                case "type":
                    list = lib.listSorted(Comparator.comparing(LibraryItem::getType)
                            .thenComparing(LibraryItem::getTitle, String.CASE_INSENSITIVE_ORDER));
                    how = "Merge sort with a two-level comparator.";
                    break;
                case "days":
                    list = lib.listSorted(Comparator.comparingInt(LibraryItem::getLoanPeriodDays));
                    how = "Merge sort by loan period.";
                    break;
                default:
                    list = lib.allItems();
                    how = "HashMap values (no particular order).";
            }
        }
        StringBuilder sb = new StringBuilder("{\"how\":").append(q(how)).append(",\"items\":[");
        for (int i = 0; i < list.size(); i++) {
            LibraryItem it = list.get(i);
            if (i > 0) sb.append(',');
            sb.append("{\"id\":").append(q(it.getId())).append(",\"type\":").append(q(it.getType()))
              .append(",\"title\":").append(q(it.getTitle())).append(",\"details\":").append(q(it.getDetails()))
              .append(",\"days\":").append(it.getLoanPeriodDays())
              .append(",\"available\":").append(it.isAvailable()).append(",\"waitlist\":[");
            List<Member> wl = lib.waitlistOf(it.getId());
            for (int k = 0; k < wl.size(); k++) sb.append(k > 0 ? "," : "").append(q(wl.get(k).getName()));
            sb.append("]}");
        }
        sb.append("],\"allItems\":[");
        List<LibraryItem> all = lib.allItems();
        for (int i = 0; i < all.size(); i++)
            sb.append(i > 0 ? "," : "").append("{\"id\":").append(q(all.get(i).getId()))
              .append(",\"title\":").append(q(all.get(i).getTitle())).append('}');
        sb.append("],\"members\":[");
        List<Member> ms = lib.allMembers();
        for (int i = 0; i < ms.size(); i++) {
            Member m = ms.get(i);
            sb.append(i > 0 ? "," : "").append("{\"id\":").append(q(m.getId())).append(",\"name\":").append(q(m.getName()))
              .append(",\"borrowed\":[");
            for (int k = 0; k < m.getBorrowed().size(); k++) {
                LibraryItem b = m.getBorrowed().get(k);
                sb.append(k > 0 ? "," : "").append("{\"id\":").append(q(b.getId())).append(",\"title\":").append(q(b.getTitle())).append('}');
            }
            sb.append("]}");
        }
        return sb.append("]}").toString();
    }

    // ---------- helpers ----------
    private static String result(boolean ok, String message) {
        return "{\"ok\":" + ok + ",\"message\":" + q(message) + "}";
    }

    private static String get(Map<String, String> p, String key) { return p.getOrDefault(key, ""); }

    /** Parses key=value&key=value (URL-encoded). */
    private static Map<String, String> parse(String s) {
        Map<String, String> m = new HashMap<>();
        if (s == null || s.isEmpty()) return m;
        for (String pair : s.split("&")) {
            int i = pair.indexOf('=');
            String k = i < 0 ? pair : pair.substring(0, i);
            String v = i < 0 ? "" : pair.substring(i + 1);
            m.put(URLDecoder.decode(k, StandardCharsets.UTF_8), URLDecoder.decode(v, StandardCharsets.UTF_8));
        }
        return m;
    }

    /** Turns a Java string into a quoted, escaped JSON string. */
    private static String q(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default: if (c < 0x20) sb.append(String.format("\\u%04x", (int) c)); else sb.append(c);
            }
        }
        return sb.append('"').toString();
    }

    private static void send(HttpExchange ex, int status, String type, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", type);
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }

    private static void seed() {
        lib.addItem(new Book("B03", "Learning Java", "Ana Cruz"));
        lib.addItem(new Book("B01", "Data Structures Made Easy", "R. Santos"));
        lib.addItem(new Book("B05", "Zero to Algorithms", "L. Reyes"));
        lib.addItem(new Magazine("M01", "Tech Weekly", "Nov 2026"));
        lib.addItem(new Book("B02", "Clean Code Basics", "J. Lim"));
        lib.addItem(new DVD("D01", "Intro to OOP", 90));
        lib.addItem(new Magazine("M02", "Science Today", "Oct 2026"));
        lib.addMember(new Member("S01", "Maria"));
        lib.addMember(new Member("S02", "Juan"));
        lib.addMember(new Member("S03", "Carla"));
    }
}
