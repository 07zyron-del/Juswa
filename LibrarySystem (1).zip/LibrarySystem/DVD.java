/** INHERITANCE: DVD is-a LibraryItem (shortest loan period). */
public class DVD extends LibraryItem {
    private final int minutes;

    public DVD(String id, String title, int minutes) {
        super(id, title);
        if (minutes <= 0) throw new IllegalArgumentException("Duration must be positive.");
        this.minutes = minutes;
    }

    @Override public int getLoanPeriodDays() { return 3; }
    @Override public String getType() { return "DVD"; }
    @Override public String getDetails() { return minutes + " minutes"; }
}
