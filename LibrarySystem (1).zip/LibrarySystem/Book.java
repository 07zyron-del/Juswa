/** INHERITANCE: Book is-a LibraryItem. */
public class Book extends LibraryItem {
    private final String author;

    public Book(String id, String title, String author) {
        super(id, title);
        if (author == null || author.isBlank()) throw new IllegalArgumentException("Author cannot be empty.");
        this.author = author.trim();
    }

    @Override public int getLoanPeriodDays() { return 14; }
    @Override public String getType() { return "Book"; }
    @Override public String getDetails() { return "by " + author; }
}
