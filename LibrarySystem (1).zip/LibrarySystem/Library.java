import java.util.*;

/**
 * Core logic. Data structures used:
 *  - HashMap  : items by ID, members by ID           -> O(1) average lookup
 *  - Queue    : one FIFO waitlist per item (Deque)   -> O(1) enqueue / dequeue
 *  - Stack    : undo history (Deque used as stack)   -> O(1) push / pop
 *  - BST      : items ordered by title               -> O(log n) average search
 */
public class Library {
    private final Map<String, LibraryItem> items = new HashMap<>();
    private final Map<String, Member> members = new HashMap<>();
    private final Map<String, Deque<Member>> waitlists = new HashMap<>();
    private final Deque<Action> undoStack = new ArrayDeque<>();
    private final TitleBST titleIndex = new TitleBST();

    // ---------- setup ----------
    public void addItem(LibraryItem item) {
        if (items.containsKey(item.getId()))
            throw new IllegalStateException("An item with ID " + item.getId() + " already exists.");
        items.put(item.getId(), item);
        waitlists.put(item.getId(), new LinkedList<>());
        titleIndex.insert(item);
    }

    public void addMember(Member m) {
        if (members.containsKey(m.getId()))
            throw new IllegalStateException("A member with ID " + m.getId() + " already exists.");
        members.put(m.getId(), m);
    }

    // ---------- lookups ----------
    public LibraryItem getItem(String id) {
        LibraryItem item = items.get(id.trim().toUpperCase());
        if (item == null) throw new IllegalStateException("No item with ID " + id.trim().toUpperCase() + ".");
        return item;
    }

    public Member getMember(String id) {
        Member m = members.get(id.trim().toUpperCase());
        if (m == null) throw new IllegalStateException("No member with ID " + id.trim().toUpperCase() + ".");
        return m;
    }

    public LibraryItem searchByTitle(String title) { return titleIndex.search(title.trim()); }

    public List<LibraryItem> browseAlphabetical() { return titleIndex.inOrder(); }

    public List<LibraryItem> listSorted(Comparator<LibraryItem> cmp) {
        return Sorter.mergeSort(new ArrayList<>(items.values()), cmp);
    }

    public List<Member> waitlistOf(String itemId) {
        return new ArrayList<>(waitlists.get(getItem(itemId).getId()));
    }

    // ---------- borrow / return / reserve ----------
    public String borrow(String memberId, String itemId) {
        Member m = getMember(memberId);
        LibraryItem item = getItem(itemId);
        if (!item.isAvailable())
            throw new IllegalStateException("\"" + item.getTitle() + "\" is on loan. Use Reserve to join the waitlist.");
        m.addBorrowed(item);
        item.setAvailable(false);
        undoStack.push(new Action(Action.Type.BORROW, m, item, null));
        return m.getName() + " borrowed \"" + item.getTitle() + "\" for " + item.getLoanPeriodDays() + " days.";
    }

    public String returnItem(String memberId, String itemId) {
        Member m = getMember(memberId);
        LibraryItem item = getItem(itemId);
        if (!m.hasBorrowed(item))
            throw new IllegalStateException(m.getName() + " did not borrow \"" + item.getTitle() + "\".");
        m.removeBorrowed(item);
        Member next = release(item);
        undoStack.push(new Action(Action.Type.RETURN, m, item, next));
        String msg = m.getName() + " returned \"" + item.getTitle() + "\".";
        if (next != null) msg += " Now loaned to " + next.getName() + " (next on the waitlist).";
        return msg;
    }

    public String reserve(String memberId, String itemId) {
        Member m = getMember(memberId);
        LibraryItem item = getItem(itemId);
        Deque<Member> q = waitlists.get(item.getId());
        if (item.isAvailable())
            throw new IllegalStateException("\"" + item.getTitle() + "\" is available. Just borrow it.");
        if (m.hasBorrowed(item))
            throw new IllegalStateException(m.getName() + " already has this item.");
        if (q.contains(m))
            throw new IllegalStateException(m.getName() + " is already on the waitlist.");
        q.addLast(m);
        return m.getName() + " is #" + q.size() + " on the waitlist for \"" + item.getTitle() + "\".";
    }

    /** Frees an item: hands it to the first person waiting, or marks it available. */
    private Member release(LibraryItem item) {
        Member next = waitlists.get(item.getId()).pollFirst();
        if (next != null) next.addBorrowed(item);   // stays on loan
        else item.setAvailable(true);
        return next;
    }

    // ---------- undo ----------
    public String undo() {
        if (undoStack.isEmpty()) throw new IllegalStateException("Nothing to undo.");
        Action a = undoStack.pop();
        if (a.type == Action.Type.BORROW) {
            a.member.removeBorrowed(a.item);
            release(a.item);
            return "Undid borrow: \"" + a.item.getTitle() + "\" taken back from " + a.member.getName() + ".";
        }
        // undo RETURN: give it back to the original borrower
        if (a.servedFromWaitlist != null) {
            a.servedFromWaitlist.removeBorrowed(a.item);
            waitlists.get(a.item.getId()).addFirst(a.servedFromWaitlist); // back to the front
        }
        a.member.addBorrowed(a.item);
        a.item.setAvailable(false);
        return "Undid return: \"" + a.item.getTitle() + "\" is back with " + a.member.getName() + ".";
    }

    public List<LibraryItem> allItems() { return new ArrayList<>(items.values()); }

    public List<Member> allMembers() { return new ArrayList<>(members.values()); }

    public int itemCount() { return items.size(); }
}
