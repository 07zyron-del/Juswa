import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.function.Supplier;

/**
 * Java Swing front end. It only handles the window; all logic stays in Library
 * (same classes, same data structures as the terminal version in Main.java).
 */
public class LibraryGUI extends JFrame {
    private static final Color GREEN = new Color(0x2F5D50);
    private static final Color PAPER = new Color(0xF6F3EE);
    private static final Color OK = new Color(0x166534);
    private static final Color BAD = new Color(0xB91C1C);
    private static final Font BODY = new Font("SansSerif", Font.PLAIN, 14);

    private final Library lib = new Library();
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Type", "Title", "Details", "Loan", "Status", "Waitlist"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JComboBox<String> viewBox = new JComboBox<>(new String[]{
            "Default order", "Browse A-Z (BST)", "Sort by ID (merge sort)",
            "Sort by type + title (merge sort)", "Sort by loan period (merge sort)"});
    private final JTextField searchField = new JTextField(16);
    private final JComboBox<Member> memberBox = new JComboBox<>();
    private final JComboBox<LibraryItem> itemBox = new JComboBox<>();
    private final JLabel howLabel = new JLabel(" ");
    private final JLabel mineLabel = new JLabel(" ");
    private final JTextArea logArea = new JTextArea(6, 40);
    private List<LibraryItem> filter = null; // search result; null = show the full catalog

    public LibraryGUI() {
        super("Library Management System");
        seed();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1120, 700);
        setLocationRelativeTo(null);
        getContentPane().setBackground(PAPER);
        setLayout(new BorderLayout(10, 10));

        add(buildHeader(), BorderLayout.NORTH);
        add(buildCatalog(), BorderLayout.CENTER);
        add(buildSidebar(), BorderLayout.EAST);
        add(buildLog(), BorderLayout.SOUTH);
        refresh();
        log("Ready. Try: Maria borrows B01, Juan reserves it, Maria returns it.");
    }

    // ---------- layout ----------
    private JComponent buildHeader() {
        JPanel p = new JPanel(new GridLayout(2, 1));
        p.setBackground(GREEN);
        p.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel t = new JLabel("Library Management System");
        t.setFont(new Font("Serif", Font.BOLD, 26));
        t.setForeground(Color.WHITE);
        JLabel s = new JLabel("Books, magazines and DVDs with waitlists, undo, a BST and merge sort");
        s.setFont(BODY);
        s.setForeground(new Color(0xCFE3DC));
        p.add(t);
        p.add(s);
        return p;
    }

    private JComponent buildCatalog() {
        JPanel p = new JPanel(new BorderLayout(6, 6));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(0, 12, 0, 0));

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        bar.setOpaque(false);
        bar.add(new JLabel("View:"));
        bar.add(viewBox);
        bar.add(new JLabel("Search ID or exact title:"));
        bar.add(searchField);
        JButton go = button("Search", true);
        JButton clear = button("Clear", false);
        bar.add(go);
        bar.add(clear);
        viewBox.addActionListener(e -> { filter = null; refresh(); });
        go.addActionListener(e -> search());
        searchField.addActionListener(e -> search());
        clear.addActionListener(e -> { searchField.setText(""); filter = null; refresh(); });

        table.setRowHeight(28);
        table.setFont(BODY);
        table.setGridColor(new Color(0xE2DDD3));
        table.setSelectionBackground(new Color(0xD7E8E2));
        table.setSelectionForeground(Color.BLACK);
        table.getTableHeader().setBackground(GREEN);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));
        int[] widths = {55, 80, 230, 140, 70, 85, 160};
        for (int i = 0; i < widths.length; i++) table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        table.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                                     boolean focus, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, focus, r, c);
                comp.setForeground("Available".equals(v) ? OK : BAD);
                comp.setFont(comp.getFont().deriveFont(Font.BOLD));
                return comp;
            }
        });
        // clicking a row selects that item in the item box
        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (e.getValueIsAdjusting() || row < 0) return;
            String id = (String) model.getValueAt(row, 0);
            for (int i = 0; i < itemBox.getItemCount(); i++)
                if (itemBox.getItemAt(i).getId().equals(id)) itemBox.setSelectedIndex(i);
        });

        howLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
        howLabel.setForeground(Color.DARK_GRAY);
        p.add(bar, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        p.add(howLabel, BorderLayout.SOUTH);
        return p;
    }

    private JComponent buildSidebar() {
        JPanel side = new JPanel();
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setOpaque(false);
        side.setBorder(new EmptyBorder(0, 0, 0, 12));
        side.setPreferredSize(new Dimension(310, 0));

        memberBox.setRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> l, Object v, int i, boolean s, boolean f) {
                Member m = (Member) v;
                return super.getListCellRendererComponent(l, m == null ? "" : m.getName() + " (" + m.getId() + ")", i, s, f);
            }
        });
        itemBox.setRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> l, Object v, int i, boolean s, boolean f) {
                LibraryItem it = (LibraryItem) v;
                return super.getListCellRendererComponent(l, it == null ? "" : it.getId() + " - " + it.getTitle(), i, s, f);
            }
        });
        memberBox.addActionListener(e -> updateMine());

        JPanel loan = section("Borrow / Return / Reserve");
        loan.add(label("Member"));
        loan.add(memberBox);
        loan.add(label("Item"));
        loan.add(itemBox);
        JPanel row = new JPanel(new GridLayout(1, 3, 6, 0));
        row.setOpaque(false);
        JButton borrow = button("Borrow", true), ret = button("Return", false), res = button("Reserve", false);
        row.add(borrow);
        row.add(ret);
        row.add(res);
        loan.add(Box.createVerticalStrut(8));
        loan.add(row);
        JButton undo = button("Undo last action", false);
        undo.setAlignmentX(LEFT_ALIGNMENT);
        loan.add(Box.createVerticalStrut(6));
        loan.add(undo);
        loan.add(Box.createVerticalStrut(8));
        loan.add(label("Borrowed by this member:"));
        loan.add(mineLabel);

        borrow.addActionListener(e -> act(() -> lib.borrow(selectedMember().getId(), selectedItem().getId())));
        ret.addActionListener(e -> act(() -> lib.returnItem(selectedMember().getId(), selectedItem().getId())));
        res.addActionListener(e -> act(() -> lib.reserve(selectedMember().getId(), selectedItem().getId())));
        undo.addActionListener(e -> act(lib::undo));

        JPanel add = section("Add new");
        JButton addItem = button("Add item...", true), addMember = button("Add member...", true);
        addItem.addActionListener(e -> addItemDialog());
        addMember.addActionListener(e -> addMemberDialog());
        JPanel row2 = new JPanel(new GridLayout(1, 2, 6, 0));
        row2.setOpaque(false);
        row2.add(addItem);
        row2.add(addMember);
        add.add(row2);

        side.add(loan);
        side.add(Box.createVerticalStrut(10));
        side.add(add);
        return side;
    }

    private JComponent buildLog() {
        logArea.setEditable(false);
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 13));
        JScrollPane sp = new JScrollPane(logArea);
        sp.setBorder(new TitledBorder("Activity"));
        sp.setPreferredSize(new Dimension(0, 130));
        sp.setOpaque(false);
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.setBorder(new EmptyBorder(0, 12, 10, 12));
        wrap.add(sp);
        return wrap;
    }

    // ---------- actions ----------
    private void search() {
        String q = searchField.getText().trim();
        if (q.isEmpty()) { filter = null; refresh(); return; }
        LibraryItem hit;
        try { hit = lib.getItem(q); }                    // HashMap lookup by ID
        catch (IllegalStateException e) { hit = lib.searchByTitle(q); } // BST lookup by title
        filter = hit == null ? List.of() : List.of(hit);
        if (hit == null) log("!! No match found for \"" + q + "\".");
        refresh();
    }

    private void act(Supplier<String> action) {
        try { log("OK: " + action.get()); }
        catch (IllegalArgumentException | IllegalStateException e) { log("!! " + e.getMessage()); }
        refresh();
    }

    private Member selectedMember() {
        Member m = (Member) memberBox.getSelectedItem();
        if (m == null) throw new IllegalStateException("Choose a member first.");
        return m;
    }

    private LibraryItem selectedItem() {
        LibraryItem i = (LibraryItem) itemBox.getSelectedItem();
        if (i == null) throw new IllegalStateException("Choose an item first.");
        return i;
    }

    private void addItemDialog() {
        JComboBox<String> type = new JComboBox<>(new String[]{"Book", "Magazine", "DVD"});
        JTextField id = new JTextField(), title = new JTextField(), extra = new JTextField();
        JLabel extraLabel = new JLabel("Author:");
        type.addActionListener(e -> extraLabel.setText(
                new String[]{"Author:", "Issue:", "Duration (minutes):"}[type.getSelectedIndex()]));
        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("Type:")); form.add(type);
        form.add(new JLabel("Item ID:")); form.add(id);
        form.add(new JLabel("Title:")); form.add(title);
        form.add(extraLabel); form.add(extra);
        if (JOptionPane.showConfirmDialog(this, form, "Add item", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE) != JOptionPane.OK_OPTION) return;
        act(() -> {
            LibraryItem item;
            switch (type.getSelectedIndex()) {
                case 0 -> item = new Book(id.getText(), title.getText(), extra.getText());
                case 1 -> item = new Magazine(id.getText(), title.getText(), extra.getText());
                default -> {
                    try { item = new DVD(id.getText(), title.getText(), Integer.parseInt(extra.getText().trim())); }
                    catch (NumberFormatException e) { throw new IllegalArgumentException("Duration must be a number."); }
                }
            }
            lib.addItem(item);
            filter = null;
            return "Added " + item.getType() + " \"" + item.getTitle() + "\".";
        });
    }

    private void addMemberDialog() {
        JTextField id = new JTextField(), name = new JTextField();
        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("Member ID:")); form.add(id);
        form.add(new JLabel("Name:")); form.add(name);
        if (JOptionPane.showConfirmDialog(this, form, "Add member", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE) != JOptionPane.OK_OPTION) return;
        act(() -> {
            Member m = new Member(id.getText(), name.getText());
            lib.addMember(m);
            return "Welcome, " + m.getName() + "!";
        });
    }

    // ---------- refresh ----------
    private void refresh() {
        List<LibraryItem> list;
        String how;
        if (filter != null) {
            list = filter;
            how = "Search: ID lookup uses the HashMap, O(1). Title lookup uses the BST, O(log n) on average.";
        } else {
            switch (viewBox.getSelectedIndex()) {
                case 1 -> { list = lib.browseAlphabetical(); how = "BST in-order traversal (left, node, right) gives A-Z in O(n)."; }
                case 2 -> { list = lib.listSorted(Comparator.comparing(LibraryItem::getId)); how = "Hand-written merge sort: O(n log n) time, O(n) space."; }
                case 3 -> { list = lib.listSorted(Comparator.comparing(LibraryItem::getType)
                        .thenComparing(LibraryItem::getTitle, String.CASE_INSENSITIVE_ORDER)); how = "Merge sort with a two-level comparator."; }
                case 4 -> { list = lib.listSorted(Comparator.comparingInt(LibraryItem::getLoanPeriodDays)); how = "Merge sort by loan period."; }
                default -> { list = lib.allItems(); how = "HashMap values (no particular order)."; }
            }
        }
        howLabel.setText("  " + how);

        model.setRowCount(0);
        for (LibraryItem i : list) {
            StringBuilder wl = new StringBuilder();
            for (Member m : lib.waitlistOf(i.getId())) wl.append(wl.length() == 0 ? "" : " > ").append(m.getName());
            model.addRow(new Object[]{i.getId(), i.getType(), i.getTitle(), i.getDetails(),
                    i.getLoanPeriodDays() + " days", i.isAvailable() ? "Available" : "On loan",
                    wl.length() == 0 ? "-" : wl.toString()});
        }

        Member keepM = (Member) memberBox.getSelectedItem();
        LibraryItem keepI = (LibraryItem) itemBox.getSelectedItem();
        memberBox.removeAllItems();
        for (Member m : lib.allMembers()) memberBox.addItem(m);
        itemBox.removeAllItems();
        for (LibraryItem i : lib.allItems()) itemBox.addItem(i);
        if (keepM != null) memberBox.setSelectedItem(keepM);
        if (keepI != null) itemBox.setSelectedItem(keepI);
        updateMine();
    }

    private void updateMine() {
        Member m = (Member) memberBox.getSelectedItem();
        if (m == null || m.getBorrowed().isEmpty()) { mineLabel.setText("Nothing borrowed."); return; }
        StringBuilder sb = new StringBuilder("<html>");
        for (LibraryItem i : m.getBorrowed()) sb.append(i.getId()).append(" - ").append(i.getTitle()).append("<br>");
        mineLabel.setText(sb.append("</html>").toString());
    }

    private void log(String msg) { logArea.append(msg + "\n"); logArea.setCaretPosition(logArea.getDocument().getLength()); }

    // ---------- small UI helpers ----------
    private JPanel section(String title) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(Color.WHITE);
        TitledBorder tb = new TitledBorder(new LineBorder(new Color(0xE2DDD3)), title);
        tb.setTitleFont(new Font("SansSerif", Font.BOLD, 13));
        p.setBorder(new CompoundBorder(tb, new EmptyBorder(6, 8, 8, 8)));
        return p;
    }

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("SansSerif", Font.PLAIN, 12));
        l.setForeground(Color.GRAY);
        l.setBorder(new EmptyBorder(6, 0, 2, 0));
        return l;
    }

    private JButton button(String text, boolean primary) {
        JButton b = new JButton(text);
        b.setFocusPainted(false);
        b.setFont(BODY);
        if (primary) { b.setBackground(GREEN); b.setForeground(Color.WHITE); b.setOpaque(true); b.setBorderPainted(false); }
        return b;
    }

    private void seed() {
        lib.addItem(new Book("B03", "Learning Java", "Ana Cruz"));
        lib.addItem(new Book("B01", "Data Structures Made Easy", "R. Santos"));
        lib.addItem(new Book("B05", "Zero to Algorithms", "L. Reyes"));
        lib.addItem(new Magazine("M01", "Tech Weekly", "Nov 2026"));
        lib.addItem(new Book("B02", "Clean Code Basics", "J. Lim"));
        lib.addItem(new DVD("D01", "Intro to OOP", 90));
        lib.addItem(new Magazine("M02", "Science Today", "Oct 2026"));
        lib.addMember(new Member("S01", "Maria"));
        lib.addMember(new Member("S02", "Juan"));
        lib.addMember(new Member("S03", "Carla"));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LibraryGUI().setVisible(true));
    }
}
