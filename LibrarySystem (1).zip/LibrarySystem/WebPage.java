/** Built-in copy of index.html (used when the file is not found next to the program). */
public class WebPage {
    public static final String HTML = """
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Library Management System</title>
<style>
:root{--bg:#f6f3ee;--card:#fff;--ink:#1f2430;--mute:#6b7280;--line:#e2ddd3;--accent:#2f5d50;--accent-ink:#fff;--okbg:#dcfce7;--ok:#166534;--outbg:#fee2e2;--out:#991b1b;--field:#fbfaf7}
@media (prefers-color-scheme:dark){:root{--bg:#14171c;--card:#1d2128;--ink:#e8e6e1;--mute:#9aa1ad;--line:#2d333d;--accent:#5fa391;--accent-ink:#0e1512;--okbg:#14351f;--ok:#86efac;--outbg:#3b1a1a;--out:#fca5a5;--field:#171a20}}
*,*::before,*::after{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
header{padding:28px 20px 8px;max-width:1180px;margin:0 auto}
h1{margin:0;font:700 26px/1.2 Georgia,"Times New Roman",serif}
header p{margin:4px 0 0;color:var(--mute)}
main{max-width:1180px;margin:0 auto;padding:12px 20px 40px;display:grid;grid-template-columns:1fr 340px;gap:16px}
@media(max-width:860px){main{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px;margin-bottom:16px}
h2{margin:0 0 10px;font-size:14px;text-transform:uppercase;letter-spacing:.06em;color:var(--mute)}
label{display:block;font-size:13px;color:var(--mute);margin:8px 0 3px}
input,select{width:100%;padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:var(--field);color:var(--ink);font:inherit}
button{padding:8px 14px;border:1px solid var(--line);border-radius:8px;background:var(--card);color:var(--ink);font:inherit;cursor:pointer}
button.primary{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
.row{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.row>*{flex:1 1 auto}
.bar{display:flex;gap:8px;flex-wrap:wrap;align-items:end;margin-bottom:10px}.bar>div{flex:1 1 180px}
.wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:14px}
th,td{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);white-space:nowrap}
th{color:var(--mute);font-weight:600;font-size:12px;text-transform:uppercase;letter-spacing:.05em}
tr.pick{background:var(--field)}
.pill{padding:2px 9px;border-radius:99px;font-size:12px;font-weight:600}
.pill.ok{background:var(--okbg);color:var(--ok)}.pill.out{background:var(--outbg);color:var(--out)}
.note{color:var(--mute);font-size:13px;margin:8px 0 0}
#log{list-style:none;margin:0;padding:0;max-height:210px;overflow:auto;font-size:14px}
#log li{padding:6px 0;border-bottom:1px solid var(--line)}
#log .err{color:var(--out)}#log .good{color:var(--ok)}
.chip{display:inline-block;margin:2px 4px 2px 0;padding:2px 9px;border:1px solid var(--line);border-radius:99px;font-size:13px}
</style>
</head>
<body>
<header>
  <h1>📚 Library Management System</h1>
  <p>HTML front end, Java back end. Every button calls the Java <code>Library</code> class on the server.</p>
</header>
<main>
<div>
  <section class="card">
    <h2>Catalog</h2>
    <div class="bar">
      <div><label for="view">View</label>
        <select id="view">
          <option value="default">Default (HashMap order)</option>
          <option value="bst">Browse A–Z (BST in-order)</option>
          <option value="id">Sort by ID (merge sort)</option>
          <option value="type">Sort by type, then title (merge sort)</option>
          <option value="days">Sort by loan period (merge sort)</option>
        </select></div>
      <div><label for="q">Search by ID or exact title</label>
        <input id="q" placeholder="e.g. B01 or Learning Java"></div>
      <button class="primary" id="go">Search</button>
      <button id="clear">Clear</button>
    </div>
    <div class="wrap"><table>
      <thead><tr><th>ID</th><th>Type</th><th>Title</th><th>Details</th><th>Loan</th><th>Status</th><th>Waitlist</th></tr></thead>
      <tbody id="rows"></tbody>
    </table></div>
    <p class="note" id="how"></p>
  </section>
  <section class="card"><h2>Activity</h2><ul id="log"></ul></section>
</div>
<aside>
  <section class="card">
    <h2>Borrow · Return · Reserve</h2>
    <label for="mem">Member</label><select id="mem"></select>
    <label for="itm">Item</label><select id="itm"></select>
    <div class="row">
      <button class="primary" id="borrow">Borrow</button>
      <button id="return">Return</button>
      <button id="reserve">Reserve</button>
    </div>
    <div class="row"><button id="undo">↶ Undo last action</button></div>
    <p class="note">Borrowed by this member:</p>
    <div id="mine"></div>
  </section>
  <section class="card">
    <h2>Add item</h2>
    <label for="t">Type</label>
    <select id="t"><option>Book</option><option>Magazine</option><option>DVD</option></select>
    <label for="nid">Item ID</label><input id="nid">
    <label for="ntitle">Title</label><input id="ntitle">
    <label for="nx" id="nxl">Author</label><input id="nx">
    <div class="row"><button class="primary" id="addItem">Add item</button></div>
  </section>
  <section class="card">
    <h2>Add member</h2>
    <label for="mid">Member ID</label><input id="mid">
    <label for="mname">Name</label><input id="mname">
    <div class="row"><button class="primary" id="addMem">Add member</button></div>
  </section>
</aside>
</main>
<script>
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
let state = null, query = "";

async function api(path, data) {
  const opt = data ? { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams(data) } : {};
  const r = await fetch(path, opt);
  return r.json();
}
function log(msg, bad) {
  const li = document.createElement("li");
  li.className = bad ? "err" : "good"; li.textContent = (bad ? "⚠ " : "✓ ") + msg;
  $("log").prepend(li);
}
async function load() {
  try { state = await api("/api/state?" + new URLSearchParams({ view: $("view").value, q: query })); render(); }
  catch (e) { log("Cannot reach the Java server. Is LibraryServer still running?", true); }
}
async function act(path, data, onOk) {
  try {
    const res = await api(path, data);
    log(res.message, !res.ok);
    if (res.ok && onOk) onOk();
  } catch (e) { log("Cannot reach the Java server.", true); }
  await load();
}

function render() {
  $("rows").innerHTML = state.items.length ? state.items.map(i =>
    `<tr><td>${esc(i.id)}</td><td>${esc(i.type)}</td><td>${esc(i.title)}</td><td>${esc(i.details)}</td><td>${i.days} days</td>` +
    `<td><span class="pill ${i.available ? "ok" : "out"}">${i.available ? "Available" : "On loan"}</span></td>` +
    `<td>${esc(i.waitlist.join(" → ") || "–")}</td></tr>`).join("")
    : `<tr><td colspan="7">No match found.</td></tr>`;
  $("how").textContent = state.how;
  const km = $("mem").value, ki = $("itm").value;
  $("mem").innerHTML = state.members.map(m => `<option value="${esc(m.id)}">${esc(m.name)} (${esc(m.id)})</option>`).join("");
  $("itm").innerHTML = state.allItems.map(i => `<option value="${esc(i.id)}">${esc(i.id)} · ${esc(i.title)}</option>`).join("");
  if (km) $("mem").value = km; if (ki) $("itm").value = ki;
  showMine();
}
function showMine() {
  const m = state && state.members.find(x => x.id === $("mem").value);
  $("mine").innerHTML = m && m.borrowed.length
    ? m.borrowed.map(b => `<span class="chip">${esc(b.id)} · ${esc(b.title)}</span>`).join("")
    : "<span class=\\"note\\">Nothing borrowed.</span>";
}
const pair = () => ({ memberId: $("mem").value, itemId: $("itm").value });

$("view").onchange = () => { query = ""; $("q").value = ""; load(); };
$("mem").onchange = showMine;
$("borrow").onclick = () => act("/api/borrow", pair());
$("return").onclick = () => act("/api/return", pair());
$("reserve").onclick = () => act("/api/reserve", pair());
$("undo").onclick = () => act("/api/undo", {});
$("go").onclick = () => { query = $("q").value.trim(); load(); };
$("q").onkeydown = e => { if (e.key === "Enter") $("go").click(); };
$("clear").onclick = () => { query = ""; $("q").value = ""; load(); };
$("t").onchange = () => { $("nxl").textContent = { Book: "Author", Magazine: "Issue", DVD: "Duration (minutes)" }[$("t").value]; };
$("addItem").onclick = () => act("/api/item", { type: $("t").value, id: $("nid").value, title: $("ntitle").value, extra: $("nx").value },
  () => { ["nid", "ntitle", "nx"].forEach(k => $(k).value = ""); });
$("addMem").onclick = () => act("/api/member", { id: $("mid").value, name: $("mname").value },
  () => { $("mid").value = $("mname").value = ""; });
load();
log("Connected. Try: Maria borrows B01, Juan reserves it, Maria returns it.");
</script>
</body>
</html>
""";
}
