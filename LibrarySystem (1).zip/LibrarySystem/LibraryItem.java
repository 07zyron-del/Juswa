/**
 * ABSTRACTION: the base type for everything the library lends.
 * ENCAPSULATION: fields are private; changes go through validated methods.
 */
public abstract class LibraryItem {
    private final String id;
    private String title;
    private boolean available = true;

    protected LibraryItem(String id, String title) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("ID cannot be empty.");
        if (title == null || title.isBlank()) throw new IllegalArgumentException("Title cannot be empty.");
        this.id = id.trim().toUpperCase();
        this.title = title.trim();
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    public void setTitle(String title) {
        if (title == null || title.isBlank()) throw new IllegalArgumentException("Title cannot be empty.");
        this.title = title.trim();
    }

    // Each subclass decides these -> POLYMORPHISM
    public abstract int getLoanPeriodDays();
    public abstract String getType();
    public abstract String getDetails();

    public String displayInfo() {
        return String.format("| %-6s | %-9s | %-26s | %-22s | %2d days | %-9s |",
                id, getType(), cut(title, 26), cut(getDetails(), 22),
                getLoanPeriodDays(), available ? "Available" : "On loan");
    }

    private static String cut(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + "~";
    }
}
