# Library Management System

A Java program that manages books, magazines and DVDs, member loans, reservation waitlists, and undo. It has three front ends sharing the same logic: a **web interface** (`LibraryServer` + `index.html`), a **Java Swing window** (`LibraryGUI`), and a **terminal version with ASCII art** (`Main`). No database: all state lives in Java data structures.

**Group members:** _(write your name(s) here)_

## How to run
Requires JDK 17 or newer.

```bash
javac -d out *.java
java -cp out LibraryServer  # web version, then open http://localhost:8080
java -cp out LibraryGUI   # Swing window
java -cp out Main         # terminal / ASCII version
```

## OOP concepts used
| Concept | Where |
|---|---|
| Classes / objects | `Library`, `Member`, `Action`, `Book`, `Magazine`, `DVD` |
| Abstraction | `LibraryItem` is abstract; it declares `getLoanPeriodDays()`, `getType()`, `getDetails()` without implementing them |
| Inheritance | `Book`, `Magazine`, `DVD` extend `LibraryItem` |
| Polymorphism | `Library` and `Main` handle everything as `LibraryItem`; each subclass overrides the abstract methods (14 / 7 / 3 day loans) |
| Encapsulation | Private fields with validation in constructors and setters (`LibraryItem`, `Member`); `Member.addBorrowed()` is package-private so only `Library` changes loans |
| Composition | `Library` has maps of items and members; `Member` has a list of borrowed items; `Action` links a member and an item |
| Separation of concerns | `LibraryServer`, `LibraryGUI` and `Main` only handle input/output; `Library` holds the logic, so both interfaces share it |

## Data structures and algorithms
| What | Where | Why | Time / Space |
|---|---|---|---|
| **HashMap** | `Library.items`, `Library.members` | Look up an item or member by ID instantly | get/put O(1) average, O(n) space |
| **Queue** (`LinkedList` as `Deque`) | `Library.waitlists` | First to reserve is first to receive the item (FIFO) | enqueue/dequeue O(1) |
| **Stack** (`ArrayDeque`) | `Library.undoStack` | Undo the most recent action first (LIFO) | push/pop O(1) |
| **Binary Search Tree** (complex DS) | `TitleBST` | Ordered by title: search by title and A-Z browsing | insert/search O(log n) average, O(n) worst case; in-order traversal O(n); O(n) space |
| **Merge sort** (algorithm, hand-written) | `Sorter` | Sort the item list by ID, type+title, or loan period using a `Comparator` | O(n log n) time in all cases, O(n) space, stable |

## Extra features
- Web interface: Java's built-in `com.sun.net.httpserver` serves `index.html` and a small JSON API (`/api/state`, `/api/borrow`, `/api/return`, `/api/reserve`, `/api/undo`, `/api/item`, `/api/member`); the page calls it with `fetch()`
- Java Swing GUI: sortable views, search box, colored status column, dialogs for adding items and members
- ASCII-art banner and bordered tables in the terminal version
- Waitlist auto-assignment when an item is returned
- Undo for borrow and return (restores the waitlist order too)
- Input validation with friendly error messages
