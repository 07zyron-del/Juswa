/** INHERITANCE: Magazine is-a LibraryItem (shorter loan period). */
public class Magazine extends LibraryItem {
    private final String issue;

    public Magazine(String id, String title, String issue) {
        super(id, title);
        if (issue == null || issue.isBlank()) throw new IllegalArgumentException("Issue cannot be empty.");
        this.issue = issue.trim();
    }

    @Override public int getLoanPeriodDays() { return 7; }
    @Override public String getType() { return "Magazine"; }
    @Override public String getDetails() { return "Issue " + issue; }
}
