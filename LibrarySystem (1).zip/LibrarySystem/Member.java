import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** A library member. COMPOSITION: a Member has a list of borrowed items. */
public class Member {
    private final String id;
    private final String name;
    private final List<LibraryItem> borrowed = new ArrayList<>();

    public Member(String id, String name) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("Member ID cannot be empty.");
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Member name cannot be empty.");
        this.id = id.trim().toUpperCase();
        this.name = name.trim();
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public List<LibraryItem> getBorrowed() { return Collections.unmodifiableList(borrowed); }

    // package-private: only Library should change a member's loans
    void addBorrowed(LibraryItem item) { borrowed.add(item); }
    void removeBorrowed(LibraryItem item) { borrowed.remove(item); }
    boolean hasBorrowed(LibraryItem item) { return borrowed.contains(item); }
}
