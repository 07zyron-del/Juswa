/** One undoable step. Stored on a Stack in Library. */
public class Action {
    public enum Type { BORROW, RETURN }

    final Type type;
    final Member member;
    final LibraryItem item;
    final Member servedFromWaitlist; // only used for RETURN (null if nobody was waiting)

    Action(Type type, Member member, LibraryItem item, Member servedFromWaitlist) {
        this.type = type;
        this.member = member;
        this.item = item;
        this.servedFromWaitlist = servedFromWaitlist;
    }
}
