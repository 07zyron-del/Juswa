import java.util.ArrayList;
import java.util.List;

/**
 * Binary Search Tree ordered by title (case-insensitive).
 * insert / search: O(log n) average, O(n) worst case (if inserted already sorted)
 * in-order traversal: O(n) -> gives items in A-Z order
 * space: O(n)
 */
public class TitleBST {
    private static class Node {
        final LibraryItem item;
        Node left, right;
        Node(LibraryItem item) { this.item = item; }
    }

    private Node root;
    private int size;

    public void insert(LibraryItem item) {
        root = insert(root, item);
        size++;
    }

    private Node insert(Node node, LibraryItem item) {
        if (node == null) return new Node(item);
        if (item.getTitle().compareToIgnoreCase(node.item.getTitle()) < 0)
            node.left = insert(node.left, item);
        else
            node.right = insert(node.right, item);
        return node;
    }

    /** Exact title match (ignores upper/lower case). Returns null if not found. */
    public LibraryItem search(String title) {
        Node cur = root;
        while (cur != null) {
            int c = title.compareToIgnoreCase(cur.item.getTitle());
            if (c == 0) return cur.item;
            cur = (c < 0) ? cur.left : cur.right;
        }
        return null;
    }

    /** Left -> Node -> Right = alphabetical order. */
    public List<LibraryItem> inOrder() {
        List<LibraryItem> out = new ArrayList<>();
        inOrder(root, out);
        return out;
    }

    private void inOrder(Node node, List<LibraryItem> out) {
        if (node == null) return;
        inOrder(node.left, out);
        out.add(node.item);
        inOrder(node.right, out);
    }

    public int size() { return size; }
}
