import java.util.*;

/** Terminal UI with ASCII art. All logic lives in Library; this class only talks to the user. */
public class Main {
    private static final Scanner in = new Scanner(System.in);
    private static final Library lib = new Library();
    private static final String LINE =
            "+--------+-----------+----------------------------+------------------------+----------+-----------+";
    private static final String HEAD =
            "| ID     | Type      | Title                      | Details                | Loan     | Status    |";

    public static void main(String[] args) {
        seed();
        boolean running = true;
        while (running) {
            printMenu();
            String choice = ask("Choose an option").trim();
            try {
                switch (choice) {
                    case "1" -> addItem();
                    case "2" -> addMember();
                    case "3" -> search();
                    case "4" -> System.out.println(ok(lib.borrow(ask("Member ID"), ask("Item ID"))));
                    case "5" -> System.out.println(ok(lib.returnItem(ask("Member ID"), ask("Item ID"))));
                    case "6" -> System.out.println(ok(lib.reserve(ask("Member ID"), ask("Item ID"))));
                    case "7" -> printTable(lib.browseAlphabetical(), "BROWSE A-Z (BST in-order traversal)");
                    case "8" -> listSorted();
                    case "9" -> System.out.println(ok(lib.undo()));
                    case "10" -> memberInfo();
                    case "0" -> running = false;
                    default -> System.out.println("  [!] Invalid choice.");
                }
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println("  [!] " + e.getMessage());
            }
            if (running) ask("\nPress Enter to continue");
        }
        System.out.println("\n  Thanks for using the library. Goodbye!\n");
    }

    // ---------- screens ----------
    private static void printMenu() {
        System.out.println();
        System.out.println("  ==========================================");
        System.out.println("   _______    _______");
        System.out.println("  /      /|  |\\      \\     LIBRARY");
        System.out.println(" /______/ |  | \\______\\    MANAGEMENT");
        System.out.println(" |      | /  \\ |      |    SYSTEM");
        System.out.println(" |______|/    \\|______|");
        System.out.println("  ==========================================");
        System.out.println("  |  1. Add item          6. Reserve       |");
        System.out.println("  |  2. Add member        7. Browse A-Z    |");
        System.out.println("  |  3. Search            8. List sorted   |");
        System.out.println("  |  4. Borrow            9. Undo last     |");
        System.out.println("  |  5. Return           10. Member info   |");
        System.out.println("  |  0. Exit                               |");
        System.out.println("  ==========================================");
    }

    private static void addItem() {
        System.out.println("  Type: 1) Book  2) Magazine  3) DVD");
        String type = ask("Type");
        String id = ask("Item ID");
        String title = ask("Title");
        LibraryItem item;
        switch (type.trim()) {
            case "1" -> item = new Book(id, title, ask("Author"));
            case "2" -> item = new Magazine(id, title, ask("Issue"));
            case "3" -> {
                int mins;
                try { mins = Integer.parseInt(ask("Duration (minutes)").trim()); }
                catch (NumberFormatException e) { throw new IllegalArgumentException("Duration must be a number."); }
                item = new DVD(id, title, mins);
            }
            default -> throw new IllegalArgumentException("Pick 1, 2 or 3.");
        }
        lib.addItem(item);
        System.out.println(ok("Added " + item.getType() + " \"" + item.getTitle() + "\"."));
    }

    private static void addMember() {
        Member m = new Member(ask("Member ID"), ask("Name"));
        lib.addMember(m);
        System.out.println(ok("Welcome, " + m.getName() + "!"));
    }

    private static void search() {
        System.out.println("  Search by: 1) ID (HashMap)  2) Exact title (BST)");
        String how = ask("Choose");
        LibraryItem found;
        if (how.trim().equals("1")) found = lib.getItem(ask("Item ID"));
        else if (how.trim().equals("2")) found = lib.searchByTitle(ask("Title"));
        else throw new IllegalArgumentException("Pick 1 or 2.");
        if (found == null) throw new IllegalStateException("No match found.");
        printTable(List.of(found), "SEARCH RESULT");
    }

    private static void listSorted() {
        System.out.println("  Sort by: 1) ID  2) Type then title  3) Loan period");
        Comparator<LibraryItem> cmp;
        switch (ask("Choose").trim()) {
            case "1" -> cmp = Comparator.comparing(LibraryItem::getId);
            case "2" -> cmp = Comparator.comparing(LibraryItem::getType)
                                        .thenComparing(LibraryItem::getTitle, String.CASE_INSENSITIVE_ORDER);
            case "3" -> cmp = Comparator.comparingInt(LibraryItem::getLoanPeriodDays);
            default -> throw new IllegalArgumentException("Pick 1, 2 or 3.");
        }
        printTable(lib.listSorted(cmp), "SORTED LIST (merge sort)");
    }

    private static void memberInfo() {
        Member m = lib.getMember(ask("Member ID"));
        System.out.println("\n  Member: " + m.getName() + " (" + m.getId() + ")");
        if (m.getBorrowed().isEmpty()) System.out.println("  No borrowed items.");
        else printTable(m.getBorrowed(), "BORROWED BY " + m.getName().toUpperCase());
        String id = ask("Check a waitlist? Item ID (or Enter to skip)");
        if (!id.isBlank()) {
            List<Member> q = lib.waitlistOf(id);
            if (q.isEmpty()) System.out.println("  Waitlist is empty.");
            else for (int i = 0; i < q.size(); i++)
                System.out.println("  " + (i + 1) + ". " + q.get(i).getName());
        }
    }

    // ---------- helpers ----------
    private static void printTable(List<LibraryItem> list, String title) {
        System.out.println("\n  " + title);
        System.out.println(LINE);
        System.out.println(HEAD);
        System.out.println(LINE);
        for (LibraryItem i : list) System.out.println(i.displayInfo());
        System.out.println(LINE);
        System.out.println("  " + list.size() + " item(s)");
    }

    private static String ask(String prompt) {
        System.out.print("  " + prompt + ": ");
        return in.hasNextLine() ? in.nextLine() : "";
    }

    private static String ok(String msg) { return "  [OK] " + msg; }

    private static void seed() {
        // inserted in mixed order so the BST stays reasonably balanced
        lib.addItem(new Book("B03", "Learning Java", "Ana Cruz"));
        lib.addItem(new Book("B01", "Data Structures Made Easy", "R. Santos"));
        lib.addItem(new Book("B05", "Zero to Algorithms", "L. Reyes"));
        lib.addItem(new Magazine("M01", "Tech Weekly", "Nov 2026"));
        lib.addItem(new Book("B02", "Clean Code Basics", "J. Lim"));
        lib.addItem(new DVD("D01", "Intro to OOP", 90));
        lib.addItem(new Magazine("M02", "Science Today", "Oct 2026"));
        lib.addMember(new Member("S01", "Maria"));
        lib.addMember(new Member("S02", "Juan"));
        lib.addMember(new Member("S03", "Carla"));
    }
}
